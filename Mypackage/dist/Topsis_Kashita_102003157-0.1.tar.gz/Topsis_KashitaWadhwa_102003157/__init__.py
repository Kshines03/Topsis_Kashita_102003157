import sys
import math
import pandas as pd
from Deepak_102003129.topsis_102003129 import *
if __name__=="__main__":
    main()
